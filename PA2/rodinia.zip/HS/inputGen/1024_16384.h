#define IN_SIZE 1024
#define TEMP_IN "temp_1024"
#define POWER_IN "power_1024"
#define MULTIPLIER 16
#define TEMP_OUT "temp_16384"
#define POWER_OUT "power_16384"

// This one doesn't work. HotspotEx generates files
// but HotspotVer does not verify them.
